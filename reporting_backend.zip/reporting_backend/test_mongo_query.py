import os
import configparser
from pymongo import MongoClient
from pprint import pprint

# Load config.ini
config = configparser.ConfigParser()
config.read(os.path.join(os.path.dirname(__file__), '../config.ini'))

if 'mongodb' in config:
    MONGO_URI = config['mongodb'].get('uri', 'mongodb://localhost:27017/')
    MONGO_DB = config['mongodb'].get('database', 'analytics')
    MONGO_COLLECTION = config['mongodb'].get('collection', 'APIBE_Reports')
else:
    MONGO_URI = os.environ.get('MONGO_URI', 'mongodb://localhost:27017/')
    MONGO_DB = os.environ.get('MONGO_DB', 'analytics')
    MONGO_COLLECTION = os.environ.get('MONGO_COLLECTION', 'APIBE_Reports')

client = MongoClient(MONGO_URI)
db = client[MONGO_DB]
collection = db[MONGO_COLLECTION]

# Query for all properties on 2025-07-19 (propertyid: null)
query = {
    "query_type": "combined_analytics",
    "event_params.date": "2025-07-19",
    "propertyid": None
}
doc = collection.find_one(query)
print("Query:")
pprint(query)
print("Result:")
pprint(doc) 