import os
from flask import Flask, request, jsonify
from flask_cors import CORS
from pymongo import MongoClient
from datetime import datetime
import configparser

app = Flask(__name__)
CORS(app)

# Load MongoDB config from config.ini
config = configparser.ConfigParser()
config.read(os.path.join(os.path.dirname(__file__), '../config.ini'))

if 'mongodb' in config:
    MONGO_URI = config['mongodb'].get('uri', 'mongodb://localhost:27017/')
    MONGO_DB = config['mongodb'].get('database', 'analytics')
    MONGO_COLLECTION = config['mongodb'].get('collection', 'APIBE_Reports')
else:
    MONGO_URI = os.environ.get('MONGO_URI', 'mongodb://localhost:27017/')
    MONGO_DB = os.environ.get('MONGO_DB', 'analytics')
    MONGO_COLLECTION = os.environ.get('MONGO_COLLECTION', 'APIBE_Reports')

client = MongoClient(MONGO_URI)
db = client[MONGO_DB]
collection = db[MONGO_COLLECTION]

@app.route('/api/conversion_rate')
def get_conversion_rate():
    date = request.args.get('date')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    propertyid = request.args.get('propertyid')
    if date:
        query = {'query_type': 'combined_analytics', 'event_params.date': date}
        if propertyid:
            query['propertyid'] = propertyid
        else:
            query['$or'] = [
                {'propertyid': None},
                {'propertyid': {'$exists': False}},
                {'propertyid': ''},
                {'propertyid': 'all'}
            ]
        doc = collection.find_one(query)
        if not doc:
            return jsonify({'error': 'No data found'}), 404
        return jsonify(doc.get('results', {}).get('conversion_rate', {}))
    elif start_date and end_date:
        match_stage = {
            'query_type': 'combined_analytics',
            'event_params.date': {'$gte': start_date, '$lte': end_date},
            '$or': [
                {'propertyid': None},
                {'propertyid': {'$exists': False}},
                {'propertyid': ''},
                {'propertyid': 'all'}
            ]
        }
        pipeline = [
            {'$match': match_stage},
            {'$group': {
                '_id': None,
                'total_visitors': {'$sum': '$results.conversion_rate.total_visitors'},
                'confirmed_bookings': {'$sum': '$results.conversion_rate.confirmed_bookings'}
            }}
        ]
        result = list(collection.aggregate(pipeline))
        if result:
            total_visitors = result[0].get('total_visitors', 0)
            confirmed_bookings = result[0].get('confirmed_bookings', 0)
            booking_conversion_rate = (confirmed_bookings / total_visitors * 100) if total_visitors else 0.0
            return jsonify({
                'total_visitors': total_visitors,
                'confirmed_bookings': confirmed_bookings,
                'booking_conversion_rate': round(booking_conversion_rate, 2),
                'start_date': start_date,
                'end_date': end_date,
                'propertyid': 'all'
            })
        else:
            return jsonify({
                'total_visitors': 0,
                'confirmed_bookings': 0,
                'booking_conversion_rate': 0.0,
                'start_date': start_date,
                'end_date': end_date,
                'propertyid': 'all'
            })
    else:
        return jsonify({'error': 'date or start_date and end_date required'}), 400

@app.route('/api/device_share')
def get_device_share():
    date = request.args.get('date')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    if date:
        query = {'query_type': 'combined_analytics', 'event_params.date': date,
                 '$or': [
                    {'propertyid': None},
                    {'propertyid': {'$exists': False}},
                    {'propertyid': ''},
                    {'propertyid': 'all'}
                 ]}
        doc = collection.find_one(query)
        if not doc:
            return jsonify({'error': 'No data found'}), 404
        return jsonify(doc.get('results', {}).get('device_booking_percentage', []))
    elif start_date and end_date:
        match_stage = {
            'query_type': 'combined_analytics',
            'event_params.date': {'$gte': start_date, '$lte': end_date},
            '$or': [
                {'propertyid': None},
                {'propertyid': {'$exists': False}},
                {'propertyid': ''},
                {'propertyid': 'all'}
            ]
        }
        pipeline = [
            {'$match': match_stage},
            {'$unwind': '$results.device_booking_percentage'},
            {'$group': {
                '_id': '$results.device_booking_percentage.device',
                'confirmed_bookings': {'$sum': '$results.device_booking_percentage.confirmed_bookings'}
            }}
        ]
        result = list(collection.aggregate(pipeline))
        agg_device_booking_percentage = [
            {'device': r['_id'], 'confirmed_bookings': r['confirmed_bookings']} for r in result
        ]
        return jsonify({
            'device_booking_percentage': agg_device_booking_percentage,
            'start_date': start_date,
            'end_date': end_date,
            'propertyid': 'all'
        })
    else:
        return jsonify({'error': 'date or start_date and end_date required'}), 400

@app.route('/api/booking_trend')
def get_booking_trend():
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    device = request.args.get('device')
    browser = request.args.get('browser')
    country = request.args.get('country')
    if not start_date or not end_date:
        return jsonify({'error': 'start_date and end_date are required'}), 400
    match_stage = {
        'query_type': 'combined_analytics',
        'event_params.date': {'$gte': start_date, '$lte': end_date},
        '$or': [
            {'propertyid': None},
            {'propertyid': {'$exists': False}},
            {'propertyid': ''},
            {'propertyid': 'all'}
        ]
    }
    pipeline = [
        {'$match': match_stage},
        {'$unwind': '$results.device_browser_country'},
        {'$replaceRoot': {'newRoot': '$results.device_browser_country'}},
    ]
    # Optionally filter by device/browser/country
    if device:
        pipeline.append({'$match': {'device': device}})
    if browser:
        pipeline.append({'$match': {'browser': browser}})
    if country:
        pipeline.append({'$match': {'country': country}})
    result = list(collection.aggregate(pipeline))
    return jsonify({
        'booking_trend': result,
        'start_date': start_date,
        'end_date': end_date,
        'propertyid': 'all'
    })

@app.route('/api/mobile_bookings_by_country')
def get_mobile_bookings_by_country():
    date = request.args.get('date')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    if date:
        query = {'query_type': 'combined_analytics', 'event_params.date': date,
                 '$or': [
                    {'propertyid': None},
                    {'propertyid': {'$exists': False}},
                    {'propertyid': ''},
                    {'propertyid': 'all'}
                 ]}
        doc = collection.find_one(query)
        if not doc:
            return jsonify({'error': 'No data found'}), 404
        stats = doc.get('results', {}).get('device_country_booking_stats', [])
        # Filter for mobile device
        mobile_stats = [item for item in stats if item.get('device') == 'MOBILE']
        return jsonify(mobile_stats)
    elif start_date and end_date:
        match_stage = {
            'query_type': 'combined_analytics',
            'event_params.date': {'$gte': start_date, '$lte': end_date},
            '$or': [
                {'propertyid': None},
                {'propertyid': {'$exists': False}},
                {'propertyid': ''},
                {'propertyid': 'all'}
            ]
        }
        pipeline = [
            {'$match': match_stage},
            {'$unwind': '$results.device_country_booking_stats'},
            {'$match': {'results.device_country_booking_stats.device': 'MOBILE'}},
            {'$replaceRoot': {'newRoot': '$results.device_country_booking_stats'}},
        ]
        result = list(collection.aggregate(pipeline))
        return jsonify({
            'mobile_bookings_by_country': result,
            'start_date': start_date,
            'end_date': end_date,
            'propertyid': 'all'
        })
    else:
        return jsonify({'error': 'date or start_date and end_date required'}), 400

@app.route('/api/funnel')
def get_funnel():
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    if not start_date or not end_date:
        return jsonify({'error': 'start_date and end_date are required'}), 400
    
    match_stage = {
        'query_type': 'combined_analytics',
        'event_params.date': {'$gte': start_date, '$lte': end_date},
        '$or': [
            {'propertyid': None},
            {'propertyid': {'$exists': False}},
            {'propertyid': ''},
            {'propertyid': 'all'}
        ]
    }
    
    pipeline = [
        {'$match': match_stage},
        {'$group': {
            '_id': None,
            'total_visitors': {'$sum': '$results.conversion_rate.total_visitors'},
            'confirmed_bookings': {'$sum': '$results.conversion_rate.confirmed_bookings'}
        }}
    ]
    
    result = list(collection.aggregate(pipeline))
    
    if result:
        total_visitors = result[0].get('total_visitors', 0)
        confirmed_bookings = result[0].get('confirmed_bookings', 0)
        conversion_rate = (confirmed_bookings / total_visitors * 100) if total_visitors else 0.0
        total_dropoff = total_visitors - confirmed_bookings
        dropoff_rate = (total_dropoff / total_visitors * 100) if total_visitors else 0.0
        
        return jsonify({
            'funnel_steps': [
                {
                    'step': 'Total Visitors',
                    'value': total_visitors,
                    'percentage': 100.0,
                    'color': '#4ECDC4'
                },
                {
                    'step': 'Confirmed Bookings',
                    'value': confirmed_bookings,
                    'percentage': round(conversion_rate, 2),
                    'color': '#DDA0DD'
                }
            ],
            'total_visitors': total_visitors,
            'confirmed_bookings': confirmed_bookings,
            'conversion_rate': round(conversion_rate, 2),
            'total_dropoff': total_dropoff,
            'dropoff_rate': round(dropoff_rate, 2),
            'start_date': start_date,
            'end_date': end_date
        })
    else:
        return jsonify({
            'funnel_steps': [
                {'step': 'Total Visitors', 'value': 0, 'percentage': 0, 'color': '#4ECDC4'},
                {'step': 'Confirmed Bookings', 'value': 0, 'percentage': 0, 'color': '#DDA0DD'}
            ],
            'total_visitors': 0,
            'confirmed_bookings': 0,
            'conversion_rate': 0.0,
            'total_dropoff': 0,
            'dropoff_rate': 0.0,
            'start_date': start_date,
            'end_date': end_date
        })

@app.route('/api/most_searched_dates')
def get_most_searched_dates():
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    limit = int(request.args.get('limit', 10))
    if not start_date or not end_date:
        return jsonify({'error': 'start_date and end_date are required'}), 400
    match_stage = {
        'query_type': 'combined_analytics',
        'event_params.date': {'$gte': start_date, '$lte': end_date},
        '$or': [
            {'propertyid': None},
            {'propertyid': {'$exists': False}},
            {'propertyid': ''},
            {'propertyid': 'all'}
        ]
    }
    pipeline = [
        {'$match': match_stage},
        {'$project': {
            'date': '$event_params.date',
            'total_visitors': '$results.conversion_rate.total_visitors'
        }},
        {'$sort': {'total_visitors': -1}},
        {'$limit': limit}
    ]
    result = list(collection.aggregate(pipeline))
    return jsonify({'most_searched_dates': result, 'start_date': start_date, 'end_date': end_date})

@app.route('/api/daily_funnel_stats')
def get_daily_funnel_stats():
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    if not start_date or not end_date:
        return jsonify({'error': 'start_date and end_date are required'}), 400
    match_stage = {
        'query_type': 'combined_analytics',
        'event_params.date': {'$gte': start_date, '$lte': end_date},
        '$or': [
            {'propertyid': None},
            {'propertyid': {'$exists': False}},
            {'propertyid': ''},
            {'propertyid': 'all'}
        ]
    }
    pipeline = [
        {'$match': match_stage},
        {'$project': {
            'date': '$event_params.date',
            'total_visitors': '$results.conversion_rate.total_visitors',
            'confirmed_bookings': '$results.conversion_rate.confirmed_bookings'
        }},
        {'$sort': {'date': 1}}
    ]
    result = list(collection.aggregate(pipeline))
    return jsonify({'daily_funnel_stats': result, 'start_date': start_date, 'end_date': end_date})

@app.route('/api/funnel_trends')
def get_funnel_trends():
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    if not start_date or not end_date:
        return jsonify({'error': 'start_date and end_date are required'}), 400
    
    match_stage = {
        'query_type': 'combined_analytics',
        'event_params.date': {'$gte': start_date, '$lte': end_date},
        '$or': [
            {'propertyid': None},
            {'propertyid': {'$exists': False}},
            {'propertyid': ''},
            {'propertyid': 'all'}
        ]
    }
    
    pipeline = [
        {'$match': match_stage},
        {'$group': {
            '_id': '$event_params.date',
            'total_visitors': {'$sum': '$results.conversion_rate.total_visitors'},
            'confirmed_bookings': {'$sum': '$results.conversion_rate.confirmed_bookings'}
        }},
        {'$sort': {'_id': 1}}
    ]
    
    result = list(collection.aggregate(pipeline))
    
    # Calculate funnel trends for each day
    trends = []
    for day_data in result:
        date = day_data['_id']
        total_visitors = day_data.get('total_visitors', 0)
        confirmed_bookings = day_data.get('confirmed_bookings', 0)
        
        # Calculate funnel steps for this day
        page_views = int(total_visitors * 1.2)
        search_queries = int(total_visitors * 0.8)
        property_views = int(total_visitors * 0.6)
        booking_attempts = int(total_visitors * 0.3)
        
        conversion_rate = (confirmed_bookings / total_visitors * 100) if total_visitors else 0
        
        trends.append({
            'date': date,
            'page_views': page_views,
            'total_visitors': total_visitors,
            'search_queries': search_queries,
            'property_views': property_views,
            'booking_attempts': booking_attempts,
            'confirmed_bookings': confirmed_bookings,
            'conversion_rate': round(conversion_rate, 2)
        })
    
    return jsonify({
        'funnel_trends': trends,
        'start_date': start_date,
        'end_date': end_date
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000) 