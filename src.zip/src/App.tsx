import React, { useState, useEffect } from 'react';
import { Box, Card, CardContent, Typography, CircularProgress, CssBaseline, Container, MenuItem, Select, FormControl, InputLabel, Grid } from '@mui/material';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { format } from 'date-fns';
import TextField from '@mui/material/TextField';
import FunnelChart from './components/FunnelChart';
import DailyStatsChart from './components/DailyStatsChart';
import DeviceStatsChart from './components/DeviceStatsChart';
import BrowserStatsChart from './components/BrowserStatsChart';
import CountryStatsChart from './components/CountryStatsChart';

const API_BASE = 'http://localhost:5000';

function formatDate(date: Date | null) {
  return date ? format(date, 'yyyy-MM-dd') : '';
}

export default function App() {
  const [startDate, setStartDate] = useState<Date | null>(new Date(new Date().setDate(new Date().getDate() - 6)));
  const [endDate, setEndDate] = useState<Date | null>(new Date());
  const [loading, setLoading] = useState(false);
  const [deviceShare, setDeviceShare] = useState<any[]>([]);

  useEffect(() => {
    if (!startDate || !endDate) return;
    const start = formatDate(startDate);
    const end = formatDate(endDate);
    setLoading(true);
    Promise.all([
      fetch(`${API_BASE}/api/device_share?start_date=${start}&end_date=${end}`).then(r => r.json()),
    ]).then(([dev]) => {
      setDeviceShare(dev.device_booking_percentage || []);
      setLoading(false);
    }).catch(() => {
      setLoading(false);
      alert('Failed to fetch data from backend. Please check your backend server.');
    });
  }, [startDate, endDate]);

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <CssBaseline />
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Typography variant="h4" gutterBottom align="center" fontWeight={700}>
          Analytics Dashboard
        </Typography>
        <Box display="flex" justifyContent="center" mb={4} gap={2}>
          <DatePicker
            label="Start date"
            value={startDate}
            onChange={(value) => setStartDate(value as Date | null)}
            maxDate={endDate || undefined}
            disableFuture
            renderInput={(params) => <TextField {...params} size="small" />}
          />
          <DatePicker
            label="End date"
            value={endDate}
            onChange={(value) => setEndDate(value as Date | null)}
            minDate={startDate || undefined}
            disableFuture
            renderInput={(params) => <TextField {...params} size="small" />}
          />
        </Box>
        {loading ? (
          <Box display="flex" justifyContent="center" alignItems="center" minHeight={300}>
            <CircularProgress />
          </Box>
        ) : (
          <Grid container spacing={4}>
            <Grid item xs={12}>
              <DeviceStatsChart 
                startDate={startDate ? formatDate(startDate) : '2025-07-19'}
                endDate={endDate ? formatDate(endDate) : '2025-07-28'}
              />
            </Grid>
            {/* New FunnelChart Component */}
            <Grid item xs={12}>
              <FunnelChart 
                startDate={startDate ? formatDate(startDate) : '2025-07-22'}
                endDate={endDate ? formatDate(endDate) : '2025-07-28'}
              />
            </Grid>
            {/* New DailyStatsChart Component */}
            <Grid item xs={12}>
              <DailyStatsChart 
                startDate={startDate ? formatDate(startDate) : '2025-07-19'}
                endDate={endDate ? formatDate(endDate) : '2025-07-28'}
              />
            </Grid>
            <Grid item xs={12}>
              <BrowserStatsChart 
                startDate={startDate ? formatDate(startDate) : '2025-07-19'}
                endDate={endDate ? formatDate(endDate) : '2025-07-28'}
              />
            </Grid>
            <Grid item xs={12}>
              <CountryStatsChart 
                startDate={startDate ? formatDate(startDate) : '2025-07-19'}
                endDate={endDate ? formatDate(endDate) : '2025-07-28'}
              />
            </Grid>
          </Grid>
        )}
      </Container>
    </LocalizationProvider>
  );
}
