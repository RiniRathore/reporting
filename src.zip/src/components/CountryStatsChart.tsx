import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  Typography,
  Box,
  CircularProgress,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper
} from '@mui/material';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend
} from 'recharts';

interface CountryStatsData {
  country: string;
  confirmed_bookings: number;
  percentage: number;
  color: string;
}

interface CountryStatsResponse {
  country_stats: CountryStatsData[];
  total_confirmed_bookings: number;
  start_date: string;
  end_date: string;
}

interface CountryStatsChartProps {
  className?: string;
  startDate?: string;
  endDate?: string;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658', '#FF6B6B', '#4ECDC4', '#45B7D1', '#FF8C00', '#32CD32', '#9370DB', '#20B2AA', '#FF69B4'];

const CountryStatsChart: React.FC<CountryStatsChartProps> = ({ 
  className, 
  startDate = '2025-07-19', 
  endDate = '2025-07-28' 
}) => {
  const [data, setData] = useState<CountryStatsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCountryStats = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const response = await fetch(
          `http://localhost:5000/api/country_stats?start_date=${startDate}&end_date=${endDate}`
        );
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        setData(result);
      } catch (err) {
        console.error('Error fetching country stats:', err);
        setError('Failed to load country stats data');
      } finally {
        setLoading(false);
      }
    };

    fetchCountryStats();
  }, [startDate, endDate]);

  if (loading) {
    return (
      <Card className={className} sx={{ minHeight: 400, boxShadow: 3 }}>
        <CardContent>
          <Box display="flex" justifyContent="center" alignItems="center" minHeight={350}>
            <CircularProgress />
          </Box>
        </CardContent>
      </Card>
    );
  }

  if (error && !data) {
    return (
      <Card className={className} sx={{ minHeight: 400, boxShadow: 3 }}>
        <CardContent>
          <Alert severity="error">{error}</Alert>
        </CardContent>
      </Card>
    );
  }

  if (!data) {
    return (
      <Card className={className} sx={{ minHeight: 400, boxShadow: 3 }}>
        <CardContent>
          <Alert severity="warning">No data available</Alert>
        </CardContent>
      </Card>
    );
  }

  // Prepare data for pie chart - limit to top 8 countries for cleaner display
  const topCountries = data.country_stats.slice(0, 8);
  const pieData = topCountries.map(item => ({
    name: item.country,
    value: item.confirmed_bookings,
    percentage: item.percentage,
    color: item.color
  }));

  // Calculate "Others" for remaining countries
  const othersBookings = data.country_stats.slice(8).reduce((sum, item) => sum + item.confirmed_bookings, 0);
  const othersPercentage = data.country_stats.slice(8).reduce((sum, item) => sum + item.percentage, 0);
  
  if (othersBookings > 0) {
    pieData.push({
      name: 'Others',
      value: othersBookings,
      percentage: Math.round(othersPercentage * 10) / 10,
      color: '#E0E0E0'
    });
  }

  return (
    <Card className={className} sx={{ minHeight: 400, boxShadow: 3 }}>
      <CardContent>
        <Typography variant="h6" sx={{ textAlign: 'center', mb: 1, fontWeight: 'bold' }}>
          Country Stats
        </Typography>
        <Typography variant="body2" sx={{ textAlign: 'center', mb: 3, color: 'text.secondary' }}>
          From {new Date(data.start_date).toLocaleDateString('en-US', { 
            day: '2-digit', 
            month: 'short', 
            year: 'numeric' 
          })} To {new Date(data.end_date).toLocaleDateString('en-US', { 
            day: '2-digit', 
            month: 'short', 
            year: 'numeric' 
          })}
        </Typography>
        
        <Box sx={{ display: 'flex', gap: 3, height: 350 }}>
          {/* Pie Chart */}
          <Box sx={{ flex: 1, height: '100%' }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percentage }) => `${name}\n${percentage}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  paddingAngle={2}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value, name) => [`${value.toLocaleString()} bookings`, name]}
                  labelFormatter={(label) => `${label}`}
                />
              </PieChart>
            </ResponsiveContainer>
          </Box>
          
          {/* Table */}
          <Box sx={{ flex: 1, maxHeight: 350, overflow: 'auto' }}>
            <TableContainer component={Paper} sx={{ maxHeight: 330 }}>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 'bold' }}>Country</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 'bold' }}>Bookings</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 'bold' }}>%</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data.country_stats.slice(0, 10).map((row, index) => (
                    <TableRow key={index} hover>
                      <TableCell component="th" scope="row">
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box
                            sx={{
                              width: 12,
                              height: 12,
                              borderRadius: '50%',
                              backgroundColor: row.color
                            }}
                          />
                          {row.country}
                        </Box>
                      </TableCell>
                      <TableCell align="right">{row.confirmed_bookings.toLocaleString()}</TableCell>
                      <TableCell align="right">{row.percentage}%</TableCell>
                    </TableRow>
                  ))}
                  {data.country_stats.length > 10 && (
                    <TableRow>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box
                            sx={{
                              width: 12,
                              height: 12,
                              borderRadius: '50%',
                              backgroundColor: '#E0E0E0'
                            }}
                          />
                          Others
                        </Box>
                      </TableCell>
                      <TableCell align="right">
                        {data.country_stats.slice(10).reduce((sum, item) => sum + item.confirmed_bookings, 0).toLocaleString()}
                      </TableCell>
                      <TableCell align="right">
                        {Math.round(data.country_stats.slice(10).reduce((sum, item) => sum + item.percentage, 0) * 10) / 10}%
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
        
        <Typography variant="body2" sx={{ textAlign: 'center', mt: 2, color: 'text.secondary' }}>
          Total Bookings: {data.total_confirmed_bookings.toLocaleString()}
        </Typography>
      </CardContent>
    </Card>
  );
};

export default CountryStatsChart; 