import React, { useState } from 'react';
import { Box, Container, Typography, TextField, Button } from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import DailyStatsChart from './DailyStatsChart';

const DailyStatsDemo: React.FC = () => {
  const [startDate, setStartDate] = useState<Date | null>(new Date('2025-07-19'));
  const [endDate, setEndDate] = useState<Date | null>(new Date('2025-07-28'));

  const formatDateForAPI = (date: Date | null): string => {
    if (!date) return '';
    return date.toISOString().split('T')[0];
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Typography variant="h4" sx={{ mb: 4, textAlign: 'center' }}>
          Daily Stats Report Demo
        </Typography>
        
        <Box sx={{ mb: 4, display: 'flex', gap: 2, justifyContent: 'center', alignItems: 'center' }}>
          <DatePicker
            label="Start Date"
            value={startDate}
            onChange={(newValue) => setStartDate(newValue)}
            renderInput={(params) => <TextField {...params} />}
          />
          <DatePicker
            label="End Date"
            value={endDate}
            onChange={(newValue) => setEndDate(newValue)}
            renderInput={(params) => <TextField {...params} />}
          />
        </Box>

        <DailyStatsChart 
          startDate={formatDateForAPI(startDate)}
          endDate={formatDateForAPI(endDate)}
        />
      </Container>
    </LocalizationProvider>
  );
};

export default DailyStatsDemo; 