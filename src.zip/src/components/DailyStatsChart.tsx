import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  Typography,
  Box,
  CircularProgress,
  Alert
} from '@mui/material';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

interface DailyStatsData {
  date: string;
  total_visitors: number;
  confirmed_bookings: number;
}

interface DailyStatsResponse {
  daily_stats: DailyStatsData[];
  total_visitors_period: number;
  start_date: string;
  end_date: string;
}

interface DailyStatsChartProps {
  className?: string;
  startDate?: string;
  endDate?: string;
}

const DailyStatsChart: React.FC<DailyStatsChartProps> = ({ 
  className, 
  startDate = '2025-07-19', 
  endDate = '2025-07-28' 
}) => {
  const [data, setData] = useState<DailyStatsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchDailyStats = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const response = await fetch(
          `http://127.0.0.1:5000/api/daily_stats?start_date=${startDate}&end_date=${endDate}`
        );
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        setData(result);
      } catch (err) {
        console.error('Error fetching daily stats:', err);
        setError('Failed to load daily stats data');
        
                       // Fallback to dummy data
               const dummyData: DailyStatsResponse = {
                 daily_stats: [
                   { date: '2025-07-19', total_visitors: 25000, confirmed_bookings: 500 },
                   { date: '2025-07-20', total_visitors: 28000, confirmed_bookings: 600 },
                   { date: '2025-07-21', total_visitors: 32000, confirmed_bookings: 700 },
                   { date: '2025-07-22', total_visitors: 35000, confirmed_bookings: 800 },
                   { date: '2025-07-23', total_visitors: 38000, confirmed_bookings: 900 },
                   { date: '2025-07-24', total_visitors: 42000, confirmed_bookings: 1000 },
                   { date: '2025-07-25', total_visitors: 45000, confirmed_bookings: 1100 },
                   { date: '2025-07-26', total_visitors: 48000, confirmed_bookings: 1200 },
                   { date: '2025-07-27', total_visitors: 52000, confirmed_bookings: 1300 },
                   { date: '2025-07-28', total_visitors: 55000, confirmed_bookings: 1400 }
                 ],
                 total_visitors_period: 400000,
                 start_date: startDate,
                 end_date: endDate
               };
        setData(dummyData);
      } finally {
        setLoading(false);
      }
    };

    fetchDailyStats();
  }, [startDate, endDate]);

  if (loading) {
    return (
      <Card className={className} sx={{ minHeight: 400, boxShadow: 3 }}>
        <CardContent>
          <Box display="flex" justifyContent="center" alignItems="center" minHeight={350}>
            <CircularProgress />
          </Box>
        </CardContent>
      </Card>
    );
  }

  if (error && !data) {
    return (
      <Card className={className} sx={{ minHeight: 400, boxShadow: 3 }}>
        <CardContent>
          <Alert severity="error">{error}</Alert>
        </CardContent>
      </Card>
    );
  }

  if (!data) {
    return (
      <Card className={className} sx={{ minHeight: 400, boxShadow: 3 }}>
        <CardContent>
          <Alert severity="warning">No data available</Alert>
        </CardContent>
      </Card>
    );
  }

  // Format dates for display and calculate guest_information for stacked chart
  const chartData = data.daily_stats.map(item => ({
    ...item,
    date: new Date(item.date).toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric' 
    }),
    guest_information: item.total_visitors - item.confirmed_bookings
  }));

  return (
    <Card className={className} sx={{ minHeight: 400, boxShadow: 3 }}>
      <CardContent>
        <Typography variant="h6" sx={{ textAlign: 'center', mb: 1, fontWeight: 'bold' }}>
          Daily Stats
        </Typography>
        <Typography variant="h5" sx={{ textAlign: 'center', mb: 1 }}>
          {data.total_visitors_period} Total Visitors
        </Typography>
        <Typography variant="body2" sx={{ textAlign: 'center', mb: 3, color: 'text.secondary' }}>
          From {new Date(data.start_date).toLocaleDateString('en-US', { 
            day: '2-digit', 
            month: 'short', 
            year: 'numeric' 
          })} To {new Date(data.end_date).toLocaleDateString('en-US', { 
            day: '2-digit', 
            month: 'short', 
            year: 'numeric' 
          })}
        </Typography>
        
                       <Box sx={{ width: '100%', height: 300 }}>
                 <ResponsiveContainer width="100%" height="100%">
                   <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                     <CartesianGrid strokeDasharray="3 3" />
                     <XAxis
                       dataKey="date"
                       tick={{ fontSize: 12 }}
                       angle={-45}
                       textAnchor="end"
                       height={80}
                     />
                     <YAxis
                       label={{ value: 'Visitors', angle: -90, position: 'insideLeft' }}
                       tick={{ fontSize: 12 }}
                     />
                     <Tooltip
                       formatter={(value: number, name: string) => [
                         value,
                         name === 'confirmed_bookings' ? 'Confirmed Bookings' :
                         name === 'guest_information' ? 'Guest Information' : name
                       ]}
                       labelFormatter={(label) => `Date: ${label}`}
                     />
                     <Legend
                       verticalAlign="bottom"
                       height={36}
                       formatter={(value: string) =>
                         value === 'confirmed_bookings' ? 'Confirmed Bookings' :
                         value === 'guest_information' ? 'Guest Information' : value
                       }
                     />
                     <Bar dataKey="confirmed_bookings" stackId="a" fill="#4CAF50" name="Confirmed Bookings" />
                     <Bar dataKey="guest_information" stackId="a" fill="#FBC02D" name="Guest Information" />
                   </BarChart>
                 </ResponsiveContainer>
               </Box>
      </CardContent>
    </Card>
  );
};

export default DailyStatsChart; 