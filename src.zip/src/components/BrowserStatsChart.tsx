import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  Typography,
  Box,
  CircularProgress,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper
} from '@mui/material';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend
} from 'recharts';

interface BrowserStatsData {
  browser: string;
  count: number;
  percentage: number;
  color: string;
}

interface BrowserStatsResponse {
  browser_stats: BrowserStatsData[];
  total_bookings: number;
  start_date: string;
  end_date: string;
}

interface BrowserStatsChartProps {
  className?: string;
  startDate?: string;
  endDate?: string;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658', '#FF6B6B', '#4ECDC4', '#45B7D1'];

const BrowserStatsChart: React.FC<BrowserStatsChartProps> = ({ 
  className, 
  startDate = '2025-07-19', 
  endDate = '2025-07-28' 
}) => {
  const [data, setData] = useState<BrowserStatsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchBrowserStats = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const response = await fetch(
          `http://localhost:5000/api/booking_trend?start_date=${startDate}&end_date=${endDate}`
        );
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        
        // Process the booking trend data to create browser stats
        // The API returns an array directly, not an object with booking_trend property
        const bookingTrend = Array.isArray(result) ? result : [];
        const browserMap: Record<string, number> = {};
        
        bookingTrend.forEach((item: any) => {
          const browser = item.browser || 'Unknown';
          browserMap[browser] = (browserMap[browser] || 0) + (item.count || 0);
        });
        
        const totalBookings = Object.values(browserMap).reduce((sum, count) => sum + count, 0);
        
        const browserStats = Object.entries(browserMap).map(([browser, count], index) => ({
          browser,
          count,
          percentage: totalBookings > 0 ? Math.round((count / totalBookings) * 100 * 10) / 10 : 0,
          color: COLORS[index % COLORS.length]
        }));
        
        // Sort by count descending and limit to top 6 browsers for cleaner display
        browserStats.sort((a, b) => b.count - a.count);
        const topBrowsers = browserStats.slice(0, 6);
        
        // Calculate "Others" for remaining browsers
        const othersCount = browserStats.slice(6).reduce((sum, item) => sum + item.count, 0);
        const othersPercentage = browserStats.slice(6).reduce((sum, item) => sum + item.percentage, 0);
        
        if (othersCount > 0) {
          topBrowsers.push({
            browser: 'Others',
            count: othersCount,
            percentage: Math.round(othersPercentage * 10) / 10,
            color: '#E0E0E0'
          });
        }
        
        const processedData: BrowserStatsResponse = {
          browser_stats: topBrowsers,
          total_bookings: totalBookings,
          start_date: startDate,
          end_date: endDate
        };
        
        setData(processedData);
      } catch (err) {
        console.error('Error fetching browser stats:', err);
        setError('Failed to load browser stats data');
      } finally {
        setLoading(false);
      }
    };

    fetchBrowserStats();
  }, [startDate, endDate]);

  if (loading) {
    return (
      <Card className={className} sx={{ minHeight: 400, boxShadow: 3 }}>
        <CardContent>
          <Box display="flex" justifyContent="center" alignItems="center" minHeight={350}>
            <CircularProgress />
          </Box>
        </CardContent>
      </Card>
    );
  }

  if (error && !data) {
    return (
      <Card className={className} sx={{ minHeight: 400, boxShadow: 3 }}>
        <CardContent>
          <Alert severity="error">{error}</Alert>
        </CardContent>
      </Card>
    );
  }

  if (!data) {
    return (
      <Card className={className} sx={{ minHeight: 400, boxShadow: 3 }}>
        <CardContent>
          <Alert severity="warning">No data available</Alert>
        </CardContent>
      </Card>
    );
  }

  // Prepare data for pie chart
  const pieData = data.browser_stats.map(item => ({
    name: item.browser,
    value: item.count,
    percentage: item.percentage,
    color: item.color
  }));

  return (
    <Card className={className} sx={{ minHeight: 400, boxShadow: 3 }}>
      <CardContent>
        <Typography variant="h6" sx={{ textAlign: 'center', mb: 1, fontWeight: 'bold' }}>
          Browser Stats
        </Typography>
        <Typography variant="body2" sx={{ textAlign: 'center', mb: 3, color: 'text.secondary' }}>
          From {new Date(data.start_date).toLocaleDateString('en-US', { 
            day: '2-digit', 
            month: 'short', 
            year: 'numeric' 
          })} To {new Date(data.end_date).toLocaleDateString('en-US', { 
            day: '2-digit', 
            month: 'short', 
            year: 'numeric' 
          })}
        </Typography>
        
        <Box sx={{ display: 'flex', gap: 3, height: 350 }}>
          {/* Pie Chart */}
          <Box sx={{ flex: 1, height: '100%' }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percentage }) => `${name}\n${percentage}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  paddingAngle={2}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value, name) => [`${value.toLocaleString()} bookings`, name]}
                  labelFormatter={(label) => `${label}`}
                />
              </PieChart>
            </ResponsiveContainer>
          </Box>

          {/* Data Table */}
          <Box sx={{ flex: 1, maxHeight: 350, overflow: 'auto' }}>
            <TableContainer component={Paper} sx={{ maxHeight: 330 }}>
              <Table stickyHeader size="small">
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 'bold' }}>Browser</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 'bold' }}>Bookings</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 'bold' }}>%</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data.browser_stats.map((item, index) => (
                    <TableRow key={index} hover>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box 
                            sx={{ 
                              width: 12, 
                              height: 12, 
                              backgroundColor: item.color, 
                              borderRadius: '50%' 
                            }} 
                          />
                          {item.browser}
                        </Box>
                      </TableCell>
                      <TableCell align="right">{item.count.toLocaleString()}</TableCell>
                      <TableCell align="right">{item.percentage}%</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
        
        <Typography variant="body2" sx={{ textAlign: 'center', mt: 2, color: 'text.secondary' }}>
          Total Bookings: {data.total_bookings.toLocaleString()}
        </Typography>
      </CardContent>
    </Card>
  );
};

export default BrowserStatsChart; 