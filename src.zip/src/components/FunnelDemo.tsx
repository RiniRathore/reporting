import React, { useState } from 'react';
import { Box, Container, Typography, TextField, Button, Grid } from '@mui/material';
import FunnelChart from './FunnelChart';

const FunnelDemo: React.FC = () => {
  const [startDate, setStartDate] = useState('2025-07-22');
  const [endDate, setEndDate] = useState('2025-07-28');

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Typography variant="h4" gutterBottom align="center" fontWeight={700}>
        Funnel Chart Demo
      </Typography>
      
      {/* Date Range Controls */}
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'center', gap: 2, flexWrap: 'wrap' }}>
        <TextField
          label="Start Date"
          type="date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
          InputLabelProps={{ shrink: true }}
          size="small"
        />
        <TextField
          label="End Date"
          type="date"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
          InputLabelProps={{ shrink: true }}
          size="small"
        />
      </Box>

      {/* Funnel Chart */}
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <FunnelChart 
            startDate={startDate}
            endDate={endDate}
          />
        </Grid>
      </Grid>

      {/* Usage Instructions */}
      <Box sx={{ mt: 4, p: 3, backgroundColor: '#f5f5f5', borderRadius: 2 }}>
        <Typography variant="h6" gutterBottom>
          How to Use FunnelChart Component:
        </Typography>
        <Typography variant="body2" paragraph>
          <strong>Basic Usage:</strong>
        </Typography>
        <Box component="pre" sx={{ backgroundColor: '#fff', p: 2, borderRadius: 1, overflow: 'auto' }}>
{`import FunnelChart from './components/FunnelChart';

// Default date range
<FunnelChart />

// Custom date range
<FunnelChart 
  startDate="2025-07-01" 
  endDate="2025-07-31" 
/>`}
        </Box>
        
        <Typography variant="body2" paragraph sx={{ mt: 2 }}>
          <strong>Features:</strong>
        </Typography>
        <ul>
          <li>✅ Fetches data from <code>/api/funnel</code> endpoint</li>
          <li>✅ Shows 2-step vertical funnel (Total Visitors → Confirmed Bookings)</li>
          <li>✅ Displays conversion rate prominently</li>
          <li>✅ Responsive and mobile-friendly</li>
          <li>✅ Loading states and error handling</li>
          <li>✅ Fallback to dummy data if API is unavailable</li>
          <li>✅ Accepts custom date ranges via props</li>
        </ul>
      </Box>
    </Container>
  );
};

export default FunnelDemo; 