import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  Typography,
  Box,
  CircularProgress,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper
} from '@mui/material';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend
} from 'recharts';

interface DeviceStatsData {
  device: string;
  confirmed_bookings: number;
  percentage: number;
  color: string;
}

interface DeviceStatsResponse {
  device_stats: DeviceStatsData[];
  total_confirmed_bookings: number;
  start_date: string;
  end_date: string;
}

interface DeviceStatsChartProps {
  className?: string;
  startDate?: string;
  endDate?: string;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658', '#FF6B6B', '#4ECDC4', '#45B7D1'];

const DeviceStatsChart: React.FC<DeviceStatsChartProps> = ({ 
  className, 
  startDate = '2025-07-19', 
  endDate = '2025-07-28' 
}) => {
  const [data, setData] = useState<DeviceStatsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchDeviceStats = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const response = await fetch(
          `http://localhost:5000/api/device_stats?start_date=${startDate}&end_date=${endDate}`
        );
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        setData(result);
      } catch (err) {
        console.error('Error fetching device stats:', err);
        setError('Failed to load device stats data');
      } finally {
        setLoading(false);
      }
    };

    fetchDeviceStats();
  }, [startDate, endDate]);

  if (loading) {
    return (
      <Card className={className} sx={{ minHeight: 400, boxShadow: 3 }}>
        <CardContent>
          <Box display="flex" justifyContent="center" alignItems="center" minHeight={350}>
            <CircularProgress />
          </Box>
        </CardContent>
      </Card>
    );
  }

  if (error && !data) {
    return (
      <Card className={className} sx={{ minHeight: 400, boxShadow: 3 }}>
        <CardContent>
          <Alert severity="error">{error}</Alert>
        </CardContent>
      </Card>
    );
  }

  if (!data) {
    return (
      <Card className={className} sx={{ minHeight: 400, boxShadow: 3 }}>
        <CardContent>
          <Alert severity="warning">No data available</Alert>
        </CardContent>
      </Card>
    );
  }

  // Prepare data for pie chart
  const pieData = data.device_stats.map(item => ({
    name: item.device,
    value: item.confirmed_bookings,
    color: item.color
  }));

  return (
    <Card className={className} sx={{ minHeight: 400, boxShadow: 3 }}>
      <CardContent>
        <Typography variant="h6" sx={{ textAlign: 'center', mb: 1, fontWeight: 'bold' }}>
          Device Stats
        </Typography>
        <Typography variant="body2" sx={{ textAlign: 'center', mb: 3, color: 'text.secondary' }}>
          From {new Date(data.start_date).toLocaleDateString('en-US', { 
            day: '2-digit', 
            month: 'short', 
            year: 'numeric' 
          })} To {new Date(data.end_date).toLocaleDateString('en-US', { 
            day: '2-digit', 
            month: 'short', 
            year: 'numeric' 
          })}
        </Typography>
        
        <Box sx={{ display: 'flex', gap: 3 }}>
          {/* Donut Chart */}
          <Box sx={{ width: '40%', minWidth: 300 }}>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value: number, name: string) => [
                    value,
                    name
                  ]}
                />
              </PieChart>
            </ResponsiveContainer>
          </Box>

          {/* Data Table */}
          <Box sx={{ width: '60%', flex: 1 }}>
            <TableContainer component={Paper} sx={{ maxHeight: 400 }}>
              <Table stickyHeader size="small">
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 'bold' }}>#</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Device</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>%</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Confirmed Bookings</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data.device_stats.map((item, index) => (
                    <TableRow key={index}>
                      <TableCell>{index + 1}</TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box 
                            sx={{ 
                              width: 12, 
                              height: 12, 
                              backgroundColor: item.color, 
                              borderRadius: '2px' 
                            }} 
                          />
                          {item.device}
                        </Box>
                      </TableCell>
                      <TableCell>{item.percentage}%</TableCell>
                      <TableCell>{item.confirmed_bookings}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
};

export default DeviceStatsChart; 